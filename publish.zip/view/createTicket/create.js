$(document).ready(function() {
    $('#description').summernote();
  });