<footer class="main-footer">
    <div class="float-right d-none d-sm-block">
      <b>Version</b> 1.0.0
    </div>
    <strong>Copyright &copy; 2024 <a href="https://www.advancespc.com" target="_blank">Advance SPC</a>.</strong> All rights reserved.
</footer>